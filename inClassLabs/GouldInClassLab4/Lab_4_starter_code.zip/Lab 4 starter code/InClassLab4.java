import java.util.Scanner;

/**
 * Draw the figure shown on the Lab4 sheet with base width provided by user.
 * 
 * @author (YOUR NAME)  // <<<<===== Duh! then remove this comment 
 * @version (February 3, 2017)
 */
public class InClassLab4
{
   public static void main(String [] args)
   {
       
       Scanner keyboard = new Scanner(System.in);
       int input = 0;
       
       // Prompt user for an odd number, & keep asking until 
       // an odd number is provided.
       do{
           System.out.print("Please enter an odd number: ");
           input = keyboard.nextInt();
        }while (TRUE);  // <<<<===== FIX THIS CONDITION then remove this comment 
       
        // Print triangle
        
        // YOUR SOLUTION GOES HERE and remove this comment
        
        
        
      }
}
