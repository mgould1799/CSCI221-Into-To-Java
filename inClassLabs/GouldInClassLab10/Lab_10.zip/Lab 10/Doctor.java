/**
 * 
 * Doctor class
 * 
 * This class simply models a doctor with a specialty. 
 *
 */
public class Doctor {
    
    // instance variable
    private String name = "Dr. Who?";
 
    public String getName(){
        return name;
    }

} 